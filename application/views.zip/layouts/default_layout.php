<div class="template-content">
	<?php echo $contents ?>
</div>