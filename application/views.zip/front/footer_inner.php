		
		
	</div>

    <!-- jequery plugins -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/owl.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/validation.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.fancybox.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/appear.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/scrollbar.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/parallax-scroll.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/data-animation.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/lax.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/particles.js"></script>

    <!-- main-js -->
    <script src="<?php echo base_url(); ?>assets/js/script.js"></script>    


</body>
</html>