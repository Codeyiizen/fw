<div class="profile-sidebar left">
	<div class="sidebar-about sidebar-widget sidebar-bg">
		<h3>Profile Settings</h3>
		<ul class="profile-navigations">
			<li><a href="<?php echo base_url(); ?>user-profile/edit">Edit Profile</a></li>
			<li><a href="<?php echo base_url(); ?>setting">Change Password</a></li>
			<li><a href="<?php echo base_url(); ?>notification">Notification</a></li>
			<li><a href="<?php echo base_url(); ?>favoritewish/logout">Logout</a></li>
		</ul>
	</div>
</div>