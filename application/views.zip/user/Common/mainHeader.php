<div class="row">
    <div class="col-sm-12">
        <div class="profile-header-tabs">
            <ul>
                <li class="<?php echo checkMainMenuActive('user-dashboard'); ?>"><a href="<?php echo base_url(); ?>user-dashboard">My Wish</a></li>
                <li class="<?php echo checkMainMenuActive('friends'); ?>"><a href="<?php echo base_url(); ?>user/friends">Friends</a></li>
                <li class="<?php echo checkMainMenuActive('registry'); ?>"><a href="<?php echo base_url(); ?>user/registry">Occasional Wishes</a></li>
                <li class="<?php echo checkMainMenuActive('family'); ?>"><a href="<?php echo base_url(); ?>family/wishes">Family Wishes</a></li>
                <li class="<?php echo checkMainMenuActive('family'); ?>"><a href="<?php echo base_url(); ?>massage/list">Message</a></li>
            </ul>
        </div>
    </div>
</div>